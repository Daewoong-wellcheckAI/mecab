namespace MeCab {
#   define VERSION "0.996/ko-0.9.2"
}
